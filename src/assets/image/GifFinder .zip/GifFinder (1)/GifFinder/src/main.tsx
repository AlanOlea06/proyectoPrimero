/*
  Punto de entrada principal de la aplicación buscador de gifs.
   renderiza el componente raíz.
 */

import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'

// Importación de la hoja de estilos global de la aplicación.
import './constants/index.css'

// Importación del componente funcional principal que contiene toda la lógica de la UI.
import { GifsApp } from './components/GifsApp'

//  Inicialización de la aplicación.
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <GifsApp />
  </StrictMode>,
)