//Recibe un array de objetos GIF y los renderiza en una grilla responsive.
 

import type { iGif } from './Giphy-Gif';

/*
  Define la estructura de las props que recibe el componente.
  Garantiza que 'gifs' sea estrictamente un array de objetos tipo
 */
interface GiftProps {
  gifs: iGif[];
}

/*
  Itera sobre la lista de GIFs y genera una tarjeta visual para cada uno.
  parametro GiftProps props - Contiene el array de gifs.
 */

export const GiftList = ( { gifs } : GiftProps ) => {
  return (
      // Contenedor principal que aplica el CSS Grid
      <div className="gifs-container">
        
        {/* Iteración sobre el array de datos */}
        { gifs.map( (gif) => (
              /* prop 'key': Esencial para el algoritmo de reconciliación de React (Virtual DOM). 
                 Debe ser un ID único para identificar cambios en la lista de manera eficiente.
              */
              <div key={ gif.id } className="gif-card">
                
                {/* Renderizado de la imagen. 'alt' es crucial para accesibilidad. */}
                <img src={ gif.url } alt={ gif.title } />
                
                {/* Título del GIF */}
                <h3>{ gif.title }</h3>
                
                {/* Dimensiones y conversión de tamaño.*/}
                <p>{ gif.width } x { gif.height } ({ (gif.size / (1024*1024)).toFixed(2) } mB)</p>
              
              </div> )
          )
        }
      </div>
  );
}