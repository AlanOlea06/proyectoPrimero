/*
  Capa de Acceso a Datos
  Este módulo se encarga exclusivamente de la comunicación con la API externa.
  Implementa el patrón Adapter para transformar la data cruda de Giphy
  en el formato simplificado que requiere nuestra aplicación.
 */

import type { iGif, iGiphyResponce } from "./Giphy-Gif";
import type { iGiphyGif } from "./Giphy-Gif";

// URL base del endpoint de búsqueda de Giphy
const BASE_URL = "https://api.giphy.com/v1/gifs/search";

/* 
  Función asíncrona que realiza la petición HTTP a Giphy.
  request - El término de búsqueda introducido por el usuario.
  limit - Cantidad máxima de resultados a obtener.
  lang - Código de idioma para los resultados.
  Promesa que resuelve en un array de objetos iGif (formato limpio).
 */

 
export const getGifsByQuery = async (request: string, limit: string, lang: string) : Promise<iGif[]> => { 
  
  // Construcción de la URL usando Template Strings.
  const response = await fetch(`${BASE_URL}?api_key=${import.meta.env.VITE_GIPHY_API_KEY}&q=${request}&limit=${limit}+&lang=${lang}}`);
    
  // Procesamiento de la respuesta:
  // await response.json(): Convierte el cuerpo de la respuesta en un objeto JS.
  // as iGiphyResponce: Type Assertion para decirle a TS que confíe en que la estructura coincide con nuestra interfaz.
  // .map(): Patrón MAPPER / Data Transfer Object. 
  //  Recorre cada gif "crudo" y extrae solo lo que necesitamos, convirtiendolos donde es necesario.
  return  (await response.json() as iGiphyResponce).data.map( (gif: iGiphyGif) => ({ 
          id: gif.id,
          title: gif.title,
          // Accedemos a la imagen original anidada profundamente en la respuesta
          url: gif.images.original.url,
          // Conversión explícita de tipos para asegurar cálculos matemáticos correctos en la vista
          width: Number(gif.images.original.width),
          height: Number(gif.images.original.height),
          size: Number(gif.images.original.size)
        })
  );
}