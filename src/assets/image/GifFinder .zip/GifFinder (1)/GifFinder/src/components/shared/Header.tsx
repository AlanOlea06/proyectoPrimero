//Muestra el título, una descripción opcional y contenido estático 


interface HeaderProps {
  title: string;        // Título principal de la aplicación
  description?: string; // Subtítulo o descripción (Opcional)
}

export const Header = ( {title, description}: HeaderProps ) => {
  return (  
      // Contenedor flexible centrado (definido en index.css)
      <div className="content-center">
        
        {/* Renderizado dinámico del título recibido por props */}
        <h1>{title}</h1>
        
        {/* Renderizado condicional : 
            Si existe 'description', crea un párrafo; si no, renderiza un string vacío. */}
        { description != null ? <p>{ description }</p> : "" }
        
        {/*  SECCIÓN DE CONTENIDO ESTÁTICO Y ENLACES  */}
        
        <p>Esto es un rickroll</p>
      
        <a href="https://youtu.be/dQw4w9WgXcQ?list=RDdQw4w9WgXcQ" target="_blank" style={ {color: "#ffffff"}}>
         Never gona give you up
        </a>
        <p> Alumnos: Daniel Flores, Jesus Burciaga y Eduardo Mandujano</p>
        <h3>Hola yo soy alexander</h3>
        
        <a href="https://youtu.be/DJstkHek4BI?list=RDDJstkHek4BI" target= "_blank" style={ {color: "#ffffff"}}> El rap de huggy bugie</a>

      </div>
  );
}