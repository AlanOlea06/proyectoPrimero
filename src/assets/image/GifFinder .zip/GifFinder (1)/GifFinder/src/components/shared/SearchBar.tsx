// Incluye la barra de búsqueda con optimización y la visualización del historial.

import { useState, useEffect } from "react";

 
// INTERFACES


//Define las propiedades esperadas para SearchBar.
interface SearchBarProps {
  type: string;          // Tipo de input 
  placerholder?: string; // Texto de ayuda en el input
  onSearch: (request: string) => void; // Función callback que se ejecuta al confirmar la búsqueda
}

// Define las propiedades para el componente de historial.

interface PreviousSeachProps {
  terms: string[]; // Array de strings con los términos buscados anteriormente
  onLabelClicked: (term: string) => void; // Función al hacer clic en un tag del historial
}




/*
  Componente controlado que maneja la entrada de texto del usuario.
  Implementa un patrón "Debounce" para retrasar la búsqueda automática mientras el usuario escribe.
 */
export const SearchBar = ( {type, placerholder = "", onSearch}: SearchBarProps ) => {
  
  const [request, setRequest] = useState (""); 
  
  /*
    Se ejecuta cada vez que cambia la variable `request`.
    Crea un temporizador de 700ms. Si el usuario deja de escribir por ese tiempo, se ejecuta onSearch.
    Si el usuario sigue escribiendo, el 'return' debería limpiar el timer anterior para reiniciar la cuenta.
   */
  useEffect( () => {
      // Configura un temporizador para ejecutar la búsqueda tras 700ms de inactividad
      const timeOutId = setTimeout( () => { onSearch(request) }, 700 );
      
      // Función de limpieza Se ejecuta antes del siguiente efecto o al desmontar.
      // Su objetivo es cancelar el timeout pendiente si el usuario escribe nuevamente antes de los 700ms.
      return clearTimeout(timeOutId);  
    }, [request, onSearch] // Dependencias: El efecto se reactiva si cambia el texto o la función padre.
  ); 

  //  Detecta si el usuario presiona la tecla "Enter" para forzar la búsqueda inmediata.
  const handleKeyDown = (event: React.KeyboardEvent) => {
    event.key === "Enter" ? handleSearch() : ""; // Validación de tecla
  };

  // Ejecuta la búsqueda manual y limpia el campo de texto.

  const handleSearch = () => { 
    onSearch(request); // Envía el término al componente padre
    setRequest("");    // Resetea el input visualmente
  };

  return (  
      <div className="search-container">
        {/* Input Controlado: Su valor está atado al estado 'request' */}
        <input 
               type={ type } 
               placeholder={ placerholder } 
               value={ request } 
               // Actualiza el estado local con cada tecla pulsada
               onChange={ (event)=>setRequest(event.target.value) } 
               // Escucha eventos de teclado
               onKeyDown={ handleKeyDown }
        />
        <button onClick={ handleSearch }>Buscar</button>
      </div>
  );
}
/*
  Renderiza una lista horizontal de los últimos términos buscados.
  Permite repetir una búsqueda al hacer clic en cualquiera de los elementos.
 */
export const PreviousSearch = ( {terms, onLabelClicked}: PreviousSeachProps ) => {
  return (  
      <div className="previous-searches">
        <h2>Búsquedas previas</h2>
        <ul className="previous-searches-list">
          {/* Mapeo del array de términos para generar elementos de lista dinámicos */}
          { terms.map( (term) => (
              <li key={ term } onClick={ () => onLabelClicked(term) }>
                { term }
              </li>
            )) 
          }  
        </ul>
      </div>    
  );
}