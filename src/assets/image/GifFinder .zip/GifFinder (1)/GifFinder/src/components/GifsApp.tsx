/*
  Componente principal de la aplicación.
  Se encarga de orquestar la lógica de negocio: gestiona el estado de los GIFs,
  el historial de búsquedas y la comunicación entre la barra de búsqueda y la lista de resultados.
 */

import { useState } from "react";
// Importación de componentes hijos y funciones de la API
import { GiftList } from "../apis/Giphy-GifsList.tsx";
import { Header } from "./shared/Header.tsx"; 
import { SearchBar, PreviousSearch } from "./shared/SearchBar.tsx";
import { getGifsByQuery } from "../apis/Giphy-Dao.ts";
import type { iGif } from "../apis/Giphy-Gif.ts";

export const GifsApp = () => {  
  // Estado para almacenar el array de objetos GIF obtenidos de la API.
  const [gifs, setGifs] = useState<iGif[]>([]);

  // Estado para almacenar el historial de términos buscados (strings).
  const [previousTerms, setPreviousTerms] = useState<string[]>([]);

  /*
    Manejador de eventos para cuando se hace clic en un elemento del historial.
    parametro request - El string del término que fue clickeado.
    Actualidad: Solo loguea el término en consola.
   */
  const handleTermClicked = (request: string) => {
    console.log({ request });
  }

  /*
    Lógica principal de búsqueda. Valida, actualiza historial y consume la API.
    parametro request - Término a buscar ingresado por el usuario.
   */
  const handleSearch = async(request: string = "") => {
    // Normalización: Elimina espacios vacíos y convierte a minúsculas.
    request = request.trim().toLocaleLowerCase();
    
    // Validación: 
    // Si el string está vacío, no hace nada.
    // Si el término YA existe en el historial (previousTerms), evita duplicados y retorna.
    if ( (request.length === 0) || previousTerms.includes(request) ) { return }
    else { 
        // Actualización de estado del Historial:
        // Agrega el nuevo 'request' al inicio del array.
        // Utiliza .splice para limitar el historial y mantener solo los elementos recientes.
        setPreviousTerms([request, ...previousTerms.splice(0,7)]); 
        
        // Llamada a la API (Data Access Object):
        // Solicita 10 gifs, en idioma inglés ("en") basado en el query.
        setGifs(await getGifsByQuery(request, "10", "en"));
    } 
  }

  // Renderizado de la interfaz gráfica (UI)
  return ( 
    <> 
      {/* Encabezado de la aplicación */}
      <Header title="Buscador de Gifs" description="Descubre y comparte Gifs" />

      {/* Barra de Búsqueda: Recibe la función handleSearch para ejecutarse al enviar el formulario */} 
      <SearchBar type="text" placerholder="Buscar gifs" onSearch={ (request) => handleSearch(request) } />

      {/* Listado de Búsquedas Previas: Muestra los tags del historial */}
      <PreviousSearch terms={ previousTerms } onLabelClicked={ (request) => handleTermClicked(request) } />

      {/* Lista de Resultados: Renderiza la grilla de GIFs si existen datos */} 
      <GiftList gifs={ gifs } />
    </>
  );
}